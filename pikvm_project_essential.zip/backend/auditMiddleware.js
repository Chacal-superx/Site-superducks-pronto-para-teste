/**
 * Middleware de Auditoria - Sistema PiKVM Médico
 * 
 * Captura automaticamente eventos para auditoria
 * Integração com sistema de logs para compliance médica
 * 
 * ✅ Auditoria automática de requisições
 * ✅ Captura de dados de contexto
 * ✅ Integração com logger service
 * ✅ Filtros por sensibilidade
 */

const loggerService = require('./logger');
const jwt = require('jsonwebtoken');

class AuditMiddleware {
    constructor() {
        // Rotas que requerem auditoria especial
        this.sensitiveRoutes = [
            '/api/patients',
            '/api/medical-records',
            '/api/webrtc',
            '/api/auth',
            '/api/admin'
        ];

        // Ações que sempre devem ser auditadas
        this.auditableActions = ['POST', 'PUT', 'PATCH', 'DELETE'];
        
        console.log('🔍 AuditMiddleware inicializado');
    }

    /**
     * Middleware principal de auditoria
     */
    auditRequest() {
        return (req, res, next) => {
            // Captura dados da requisição
            const startTime = Date.now();
            const requestData = this.extractRequestData(req);

            // Intercepta a resposta
            const originalSend = res.send;
            res.send = function(data) {
                const endTime = Date.now();
                const responseTime = endTime - startTime;
                
                // Processa auditoria após resposta
                setImmediate(() => {
                    auditMiddleware.processAudit(req, res, requestData, responseTime, data);
                });

                return originalSend.call(this, data);
            };

            next();
        };
    }

    /**
     * Extrai dados relevantes da requisição
     */
    extractRequestData(req) {
        return {
            method: req.method,
            url: req.originalUrl,
            path: req.path,
            ip: req.ip || req.connection.remoteAddress,
            userAgent: req.get('User-Agent'),
            timestamp: new Date().toISOString(),
            headers: this.sanitizeHeaders(req.headers),
            query: req.query,
            body: this.sanitizeBody(req.body),
            user: this.extractUserFromToken(req)
        };
    }

    /**
     * Extrai informações do usuário do token JWT
     */
    extractUserFromToken(req) {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader || !authHeader.startsWith('Bearer ')) {
                return null;
            }

            const token = authHeader.substring(7);
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            
            return {
                id: decoded.userId,
                email: decoded.email,
                role: decoded.role
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Sanitiza headers removendo dados sensíveis
     */
    sanitizeHeaders(headers) {
        const sanitized = { ...headers };
        const sensitiveHeaders = ['authorization', 'cookie', 'x-api-key'];
        
        sensitiveHeaders.forEach(header => {
            if (sanitized[header]) {
                sanitized[header] = '[REDACTED]';
            }
        });

        return sanitized;
    }

    /**
     * Sanitiza body removendo dados sensíveis
     */
    sanitizeBody(body) {
        if (!body || typeof body !== 'object') {
            return body;
        }

        const sanitized = { ...body };
        const sensitiveFields = [
            'password', 'token', 'secret', 'key', 'totp_code', 
            'backup_code', 'recaptcha_token', 'cpf', 'rg'
        ];
        
        sensitiveFields.forEach(field => {
            if (sanitized[field]) {
                sanitized[field] = '[REDACTED]';
            }
        });

        return sanitized;
    }

    /**
     * Processa auditoria após requisição
     */
    processAudit(req, res, requestData, responseTime, responseData) {
        try {
            const isSensitiveRoute = this.isSensitiveRoute(requestData.path);
            const isAuditableAction = this.auditableActions.includes(requestData.method);
            const isAuthRoute = requestData.path.startsWith('/api/auth');

            // Sempre audita rotas de autenticação
            if (isAuthRoute) {
                this.auditAuthenticationEvent(requestData, res.statusCode);
            }

            // Audita rotas sensíveis ou ações modificadoras
            if (isSensitiveRoute || isAuditableAction) {
                this.auditGeneralEvent(requestData, res.statusCode, responseTime);
            }

            // Audita acesso a dados de pacientes
            if (this.isPatientDataAccess(requestData)) {
                this.auditPatientDataEvent(requestData, res.statusCode);
            }

            // Audita sessões WebRTC
            if (this.isWebRTCEvent(requestData)) {
                this.auditWebRTCEvent(requestData, res.statusCode);
            }

            // Detecta tentativas de acesso negadas
            if (res.statusCode === 401 || res.statusCode === 403) {
                this.auditAccessDenied(requestData, res.statusCode);
            }

        } catch (error) {
            loggerService.error('Erro no processamento de auditoria', {
                error: error.message,
                stack: error.stack,
                request_path: requestData.path
            });
        }
    }

    /**
     * Verifica se é rota sensível
     */
    isSensitiveRoute(path) {
        return this.sensitiveRoutes.some(route => path.startsWith(route));
    }

    /**
     * Verifica se é acesso a dados de paciente
     */
    isPatientDataAccess(requestData) {
        const patientRoutes = ['/api/patients', '/api/medical-records'];
        return patientRoutes.some(route => requestData.path.startsWith(route));
    }

    /**
     * Verifica se é evento WebRTC
     */
    isWebRTCEvent(requestData) {
        return requestData.path.startsWith('/api/webrtc') || 
               requestData.path.includes('session');
    }

    /**
     * Audita eventos de autenticação
     */
    auditAuthenticationEvent(requestData, statusCode) {
        const success = statusCode >= 200 && statusCode < 300;
        const action = this.getAuthAction(requestData.path);

        if (action === 'login') {
            loggerService.auditLogin(
                requestData.user?.id || 'anonymous',
                requestData.body?.email || 'unknown',
                requestData.ip,
                requestData.userAgent,
                success,
                success ? null : `HTTP ${statusCode}`
            );
        } else if (action === 'mfa') {
            loggerService.auditMFA(
                requestData.user?.id || 'anonymous',
                requestData.ip,
                requestData.body?.totp_code ? 'totp' : 'backup_code',
                success,
                success ? null : `HTTP ${statusCode}`
            );
        }
    }

    /**
     * Determina ação de autenticação baseada na rota
     */
    getAuthAction(path) {
        if (path.includes('login')) return 'login';
        if (path.includes('mfa') || path.includes('verify')) return 'mfa';
        if (path.includes('logout')) return 'logout';
        return 'auth_general';
    }

    /**
     * Audita eventos gerais
     */
    auditGeneralEvent(requestData, statusCode, responseTime) {
        loggerService.info('API request processed', {
            event_type: 'api_access',
            method: requestData.method,
            path: requestData.path,
            user_id: requestData.user?.id,
            ip_address: requestData.ip,
            status_code: statusCode,
            response_time_ms: responseTime,
            user_agent: requestData.userAgent,
            compliance_category: 'api_usage'
        });
    }

    /**
     * Audita acesso a dados de pacientes
     */
    auditPatientDataEvent(requestData, statusCode) {
        if (statusCode >= 200 && statusCode < 300) {
            const patientId = this.extractPatientId(requestData);
            const action = this.mapMethodToAction(requestData.method);
            const dataType = this.inferDataType(requestData.path);

            if (patientId && requestData.user?.id) {
                loggerService.auditPatientDataAccess(
                    requestData.user.id,
                    patientId,
                    dataType,
                    action,
                    requestData.ip
                );
            }
        }
    }

    /**
     * Audita eventos WebRTC
     */
    auditWebRTCEvent(requestData, statusCode) {
        if (statusCode >= 200 && statusCode < 300) {
            const sessionId = requestData.body?.session_id || 
                            requestData.query?.session_id || 
                            'unknown';
            const patientId = this.extractPatientId(requestData);
            const action = this.inferWebRTCAction(requestData);

            if (requestData.user?.id) {
                loggerService.auditWebRTCSession(
                    requestData.user.id,
                    patientId,
                    sessionId,
                    action,
                    {
                        connectionType: requestData.body?.connection_type,
                        deviceId: requestData.body?.device_id
                    }
                );
            }
        }
    }

    /**
     * Audita tentativas de acesso negadas
     */
    auditAccessDenied(requestData, statusCode) {
        const reason = statusCode === 401 ? 'unauthorized' : 'forbidden';
        
        loggerService.auditAccessDenied(
            requestData.user?.id || 'anonymous',
            requestData.path,
            reason,
            requestData.ip,
            requestData.userAgent
        );
    }

    /**
     * Extrai ID do paciente da requisição
     */
    extractPatientId(requestData) {
        // Tenta extrair de diferentes locais
        return requestData.body?.patient_id || 
               requestData.query?.patient_id || 
               requestData.params?.patientId ||
               this.extractFromPath(requestData.path, 'patients') ||
               null;
    }

    /**
     * Extrai ID de uma entidade do path
     */
    extractFromPath(path, entity) {
        const regex = new RegExp(`/${entity}/([^/]+)`);
        const match = path.match(regex);
        return match ? match[1] : null;
    }

    /**
     * Mapeia método HTTP para ação de auditoria
     */
    mapMethodToAction(method) {
        const actionMap = {
            'GET': 'view',
            'POST': 'create',
            'PUT': 'update',
            'PATCH': 'update',
            'DELETE': 'delete'
        };
        return actionMap[method] || 'unknown';
    }

    /**
     * Infere tipo de dados baseado na rota
     */
    inferDataType(path) {
        if (path.includes('medical-record')) return 'medical_record';
        if (path.includes('personal')) return 'personal_info';
        if (path.includes('diagnostic')) return 'diagnostic';
        if (path.includes('patient')) return 'patient_data';
        return 'general';
    }

    /**
     * Infere ação WebRTC baseada na requisição
     */
    inferWebRTCAction(requestData) {
        const path = requestData.path.toLowerCase();
        const method = requestData.method;

        if (method === 'POST' && path.includes('start')) return 'start';
        if (method === 'POST' && path.includes('end')) return 'end';
        if (method === 'POST' && path.includes('connect')) return 'connect';
        if (method === 'DELETE') return 'disconnect';
        
        return 'session_event';
    }

    /**
     * Middleware para auditoria de modificações de dados
     */
    auditDataModification() {
        return (req, res, next) => {
            if (this.auditableActions.includes(req.method)) {
                // Intercepta resposta para capturar mudanças
                const originalSend = res.send;
                res.send = function(data) {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        const user = auditMiddleware.extractUserFromToken(req);
                        if (user?.id) {
                            loggerService.auditDataModification(
                                user.id,
                                auditMiddleware.inferEntityType(req.path),
                                auditMiddleware.extractEntityId(req),
                                req.body,
                                req.ip
                            );
                        }
                    }
                    return originalSend.call(this, data);
                };
            }
            next();
        };
    }

    /**
     * Infere tipo de entidade baseado na rota
     */
    inferEntityType(path) {
        if (path.includes('patient')) return 'patient';
        if (path.includes('medical-record')) return 'medical_record';
        if (path.includes('user')) return 'user';
        if (path.includes('config')) return 'configuration';
        return 'unknown';
    }

    /**
     * Extrai ID da entidade sendo modificada
     */
    extractEntityId(req) {
        return req.params?.id || 
               req.params?.patientId || 
               req.params?.userId || 
               req.body?.id ||
               'unknown';
    }
}

// Singleton
const auditMiddleware = new AuditMiddleware();

module.exports = auditMiddleware;

