/**
 * Serviço de Rate Limiting - Sistema PiKVM Médico
 * 
 * Implementa proteção avançada contra ataques de força bruta
 * Correção da falha: Bloqueio de conta inadequado
 * 
 * ✅ Rate limiting por IP e usuário
 * ✅ Bloqueio progressivo
 * ✅ Whitelist de IPs confiáveis
 * ✅ Logs de tentativas suspeitas
 */

const rateLimit = require('express-rate-limit');

class RateLimiterService {
    constructor() {
        // IPs confiáveis (whitelist)
        this.trustedIPs = [
            '127.0.0.1',
            '::1',
            '10.0.0.0/8',
            '172.16.0.0/12',
            '192.168.0.0/16'
        ];

        // Armazenamento em memória para contadores (em produção usar Redis)
        this.counters = new Map();
        this.progressiveDelays = new Map();

        console.log('🛡️ RateLimiterService inicializado');
    }

    /**
     * Rate limiter global (aplicado a todas as rotas)
     */
    get globalLimiter() {
        return rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutos
            max: 1000, // 1000 requests por IP
            message: {
                error: 'Muitas requisições. Tente novamente em 15 minutos.',
                type: 'rate_limit_exceeded',
                retry_after: 15 * 60
            },
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => this.isWhitelisted(req.ip),
            onLimitReached: (req) => {
                console.log(`⚠️ Rate limit global atingido para IP: ${req.ip}`);
                this.logSuspiciousActivity(req.ip, 'global_rate_limit');
            }
        });
    }

    /**
     * Rate limiter para login (mais restritivo)
     */
    get loginLimiter() {
        return rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutos
            max: 5, // 5 tentativas por IP
            message: {
                error: 'Muitas tentativas de login. Tente novamente em 15 minutos.',
                type: 'login_rate_limit',
                retry_after: 15 * 60,
                captcha_required: true
            },
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => this.isWhitelisted(req.ip),
            skipSuccessfulRequests: true, // Não conta logins bem-sucedidos
            onLimitReached: (req) => {
                console.log(`🚨 Rate limit de login atingido para IP: ${req.ip}`);
                this.logSuspiciousActivity(req.ip, 'login_brute_force', req.body?.email);
                this.sendSecurityAlert(req.ip, 'login_brute_force');
            }
        });
    }

    /**
     * Rate limiter para MFA (moderado)
     */
    get mfaLimiter() {
        return rateLimit({
            windowMs: 5 * 60 * 1000, // 5 minutos
            max: 10, // 10 tentativas por IP
            message: {
                error: 'Muitas tentativas de MFA. Tente novamente em 5 minutos.',
                type: 'mfa_rate_limit',
                retry_after: 5 * 60
            },
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => this.isWhitelisted(req.ip),
            onLimitReached: (req) => {
                console.log(`⚠️ Rate limit MFA atingido para IP: ${req.ip}`);
                this.logSuspiciousActivity(req.ip, 'mfa_brute_force');
            }
        });
    }

    /**
     * Rate limiter para APIs gerais
     */
    get apiLimiter() {
        return rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutos
            max: 100, // 100 requests por IP
            message: {
                error: 'Muitas requisições à API. Tente novamente em 15 minutos.',
                type: 'api_rate_limit',
                retry_after: 15 * 60
            },
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => this.isWhitelisted(req.ip)
        });
    }

    /**
     * Rate limiter para rotas de autenticação
     */
    get authLimiter() {
        return rateLimit({
            windowMs: 10 * 60 * 1000, // 10 minutos
            max: 20, // 20 requests por IP
            message: {
                error: 'Muitas tentativas de autenticação. Tente novamente em 10 minutos.',
                type: 'auth_rate_limit',
                retry_after: 10 * 60
            },
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => this.isWhitelisted(req.ip)
        });
    }

    /**
     * Verifica se IP está na whitelist
     */
    isWhitelisted(ip) {
        return this.trustedIPs.some(trustedIP => {
            if (trustedIP.includes('/')) {
                // CIDR notation - implementação básica
                return ip.startsWith(trustedIP.split('/')[0].slice(0, -1));
            }
            return ip === trustedIP;
        });
    }

    /**
     * Implementa bloqueio progressivo
     */
    getProgressiveDelay(ip, action = 'login') {
        const key = `${ip}:${action}`;
        const attempts = this.progressiveDelays.get(key) || 0;
        
        const delays = {
            0: 0,      // Primeira tentativa
            1: 0,      // Segunda tentativa
            2: 0,      // Terceira tentativa
            3: 60,     // 1 minuto
            4: 300,    // 5 minutos
            5: 900,    // 15 minutos
            6: 3600,   // 1 hora
            7: 7200,   // 2 horas
            8: 14400,  // 4 horas
            9: 28800   // 8 horas
        };

        const delay = delays[Math.min(attempts, 9)] || 28800;
        
        if (delay > 0) {
            console.log(`⏰ Bloqueio progressivo: ${ip} deve aguardar ${delay}s`);
        }

        return delay;
    }

    /**
     * Registra tentativa falhada para bloqueio progressivo
     */
    recordFailedAttempt(ip, action = 'login') {
        const key = `${ip}:${action}`;
        const current = this.progressiveDelays.get(key) || 0;
        this.progressiveDelays.set(key, current + 1);
        
        console.log(`📝 Tentativa falhada registrada: ${ip} - ${action} (${current + 1})`);
        
        // Limpa após 24h (simulado)
        setTimeout(() => {
            this.progressiveDelays.delete(key);
        }, 24 * 60 * 60 * 1000);
    }

    /**
     * Reseta contador de tentativas falhadas (após sucesso)
     */
    resetFailedAttempts(ip, action = 'login') {
        const key = `${ip}:${action}`;
        this.progressiveDelays.delete(key);
        
        console.log(`✅ Contador de tentativas resetado: ${ip} - ${action}`);
    }

    /**
     * Registra atividade suspeita
     */
    logSuspiciousActivity(ip, type, additionalInfo = null) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            ip: ip,
            type: type,
            additional_info: additionalInfo,
            severity: this.getSeverityLevel(type)
        };

        console.log(`🚨 Atividade suspeita registrada:`, logEntry);
    }

    /**
     * Determina nível de severidade
     */
    getSeverityLevel(type) {
        const severityMap = {
            'login_brute_force': 'HIGH',
            'mfa_brute_force': 'MEDIUM',
            'global_rate_limit': 'LOW',
            'api_abuse': 'MEDIUM',
            'suspicious_pattern': 'HIGH'
        };

        return severityMap[type] || 'LOW';
    }

    /**
     * Envia alerta de segurança
     */
    sendSecurityAlert(ip, type) {
        console.log(`🚨 ALERTA DE SEGURANÇA: ${type} detectado do IP ${ip}`);
    }
}

// Singleton
const rateLimiterService = new RateLimiterService();

module.exports = rateLimiterService;