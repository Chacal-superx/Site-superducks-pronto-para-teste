/**
 * Serviço de Logging e Auditoria - Sistema PiKVM Médico
 * 
 * Implementa logs estruturados para compliance médica
 * Correção da falha: WebRTC sem auditoria + Logs centralizados inadequados
 * 
 * ✅ Logs estruturados com Winston
 * ✅ Rotação diária de arquivos
 * ✅ Auditoria de ações médicas
 * ✅ Compliance LGPD/CFM
 * ✅ Correlação de eventos
 */

const winston = require('winston');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

class LoggerService {
    constructor() {
        // Cria diretórios de logs se não existirem
        this.logDir = path.join(__dirname, '../logs');
        this.ensureLogDirectory();

        // Configurações de retenção
        this.retentionDays = {
            audit: '7y',      // 7 anos para auditoria médica
            security: '2y',   // 2 anos para logs de segurança
            application: '90d', // 90 dias para logs de aplicação
            access: '1y'      // 1 ano para logs de acesso
        };

        // Inicializa loggers
        this.initializeLoggers();
        
        console.log('📝 LoggerService inicializado');
    }

    /**
     * Garante que diretório de logs existe
     */
    ensureLogDirectory() {
        const dirs = [
            this.logDir,
            path.join(this.logDir, 'audit'),
            path.join(this.logDir, 'security'),
            path.join(this.logDir, 'application'),
            path.join(this.logDir, 'access')
        ];

        dirs.forEach(dir => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });
    }

    /**
     * Inicializa todos os loggers
     */
    initializeLoggers() {
        // Formato personalizado para logs estruturados
        const customFormat = winston.format.combine(
            winston.format.timestamp({
                format: 'YYYY-MM-DD HH:mm:ss.SSS'
            }),
            winston.format.errors({ stack: true }),
            winston.format.json()
        );

        // Logger de Auditoria (crítico para compliance)
        this.auditLogger = winston.createLogger({
            level: 'info',
            format: customFormat,
            transports: [
                new winston.transports.File({
                    filename: path.join(this.logDir, 'audit', 'audit.log'),
                    maxsize: 100 * 1024 * 1024, // 100MB
                    maxFiles: 365 // 1 ano de arquivos
                })
            ]
        });

        // Logger de Segurança
        this.securityLogger = winston.createLogger({
            level: 'info',
            format: customFormat,
            transports: [
                new winston.transports.File({
                    filename: path.join(this.logDir, 'security', 'security.log'),
                    maxsize: 50 * 1024 * 1024 // 50MB
                }),
                new winston.transports.Console({
                    format: winston.format.combine(
                        winston.format.colorize(),
                        winston.format.simple()
                    )
                })
            ]
        });

        // Logger de Aplicação
        this.appLogger = winston.createLogger({
            level: 'debug',
            format: customFormat,
            transports: [
                new winston.transports.File({
                    filename: path.join(this.logDir, 'application', 'app.log'),
                    maxsize: 50 * 1024 * 1024 // 50MB
                }),
                new winston.transports.Console({
                    level: 'info',
                    format: winston.format.combine(
                        winston.format.colorize(),
                        winston.format.simple()
                    )
                })
            ]
        });

        // Logger de Acesso
        this.accessLogger = winston.createLogger({
            level: 'info',
            format: customFormat,
            transports: [
                new winston.transports.File({
                    filename: path.join(this.logDir, 'access', 'access.log'),
                    maxsize: 100 * 1024 * 1024 // 100MB
                })
            ]
        });

        // Stream para Morgan (HTTP access logs)
        this.stream = {
            write: (message) => {
                this.accessLogger.info(message.trim());
            }
        };
    }

    /**
     * AUDITORIA - Login/Logout
     */
    auditLogin(userId, email, ip, userAgent, success = true, reason = null) {
        const event = {
            event_type: 'authentication',
            action: 'login',
            user_id: userId,
            user_email: email,
            ip_address: ip,
            user_agent: userAgent,
            success: success,
            failure_reason: reason,
            session_id: this.generateSessionId(),
            compliance_category: 'access_control'
        };

        this.auditLogger.info('User login attempt', event);
        
        if (!success) {
            this.securityLogger.warn('Failed login attempt', event);
        }
    }

    /**
     * AUDITORIA - MFA
     */
    auditMFA(userId, ip, method, success = true, reason = null) {
        const event = {
            event_type: 'authentication',
            action: 'mfa_verification',
            user_id: userId,
            ip_address: ip,
            mfa_method: method, // 'totp' ou 'backup_code'
            success: success,
            failure_reason: reason,
            compliance_category: 'multi_factor_auth'
        };

        this.auditLogger.info('MFA verification', event);
        
        if (!success) {
            this.securityLogger.warn('MFA verification failed', event);
        }
    }

    /**
     * AUDITORIA - Acesso a dados de paciente
     */
    auditPatientDataAccess(userId, patientId, dataType, action, ip) {
        const event = {
            event_type: 'data_access',
            action: action, // 'view', 'edit', 'delete', 'export'
            user_id: userId,
            patient_id: patientId,
            data_type: dataType, // 'medical_record', 'personal_info', 'diagnostic'
            ip_address: ip,
            timestamp: new Date().toISOString(),
            compliance_category: 'patient_data_access',
            retention_required: true,
            sensitivity_level: 'high'
        };

        this.auditLogger.info('Patient data access', event);
    }

    /**
     * AUDITORIA - Sessão WebRTC/PiKVM
     */
    auditWebRTCSession(userId, patientId, sessionId, action, details = {}) {
        const event = {
            event_type: 'webrtc_session',
            action: action, // 'start', 'end', 'connection_failed'
            user_id: userId,
            patient_id: patientId,
            session_id: sessionId,
            duration: details.duration || null,
            quality_metrics: details.quality || null,
            connection_type: details.connectionType || null,
            pikvm_device_id: details.deviceId || null,
            compliance_category: 'telemedicine_session',
            retention_required: true
        };

        this.auditLogger.info('WebRTC session event', event);
        
        // Log crítico para sessões médicas
        if (action === 'start') {
            this.securityLogger.info('Telemedicine session started', event);
        }
    }

    /**
     * AUDITORIA - Modificações de dados
     */
    auditDataModification(userId, entityType, entityId, changes, ip) {
        const event = {
            event_type: 'data_modification',
            action: 'update',
            user_id: userId,
            entity_type: entityType, // 'patient', 'medical_record', 'user'
            entity_id: entityId,
            changes: this.sanitizeChanges(changes),
            ip_address: ip,
            compliance_category: 'data_integrity',
            retention_required: true
        };

        this.auditLogger.info('Data modification', event);
    }

    /**
     * APLICAÇÃO - Logs gerais
     */
    info(message, meta = {}) {
        this.appLogger.info(message, meta);
    }

    warn(message, meta = {}) {
        this.appLogger.warn(message, meta);
    }

    error(message, meta = {}) {
        this.appLogger.error(message, meta);
    }

    debug(message, meta = {}) {
        this.appLogger.debug(message, meta);
    }

    /**
     * Gera ID de sessão único
     */
    generateSessionId() {
        return crypto.randomBytes(16).toString('hex');
    }

    /**
     * Sanitiza mudanças para não vazar dados sensíveis
     */
    sanitizeChanges(changes) {
        const sanitized = { ...changes };
        const sensitiveFields = ['password', 'token', 'secret', 'key'];
        
        for (const field of sensitiveFields) {
            if (sanitized[field]) {
                sanitized[field] = '[REDACTED]';
            }
        }
        
        return sanitized;
    }

    /**
     * Obtém estatísticas de logs
     */
    getLogStats() {
        return {
            audit_logs_active: true,
            security_logs_active: true,
            retention_policy: this.retentionDays,
            log_directory: this.logDir,
            last_rotation: new Date().toISOString()
        };
    }
}

// Singleton
const loggerService = new LoggerService();

module.exports = loggerService;