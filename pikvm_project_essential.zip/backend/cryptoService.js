/**
 * Serviço de Criptografia - Sistema PiKVM Médico
 * 
 * Implementa criptografia AES-256-GCM para dados médicos sensíveis
 * Correção da falha crítica: Dados não criptografados
 * 
 * ✅ Criptografia AES-256-GCM
 * ✅ Hash seguro com bcrypt
 * ✅ Geração de chaves aleatórias
 * ✅ Validação de integridade
 */

const crypto = require('crypto');
const bcrypt = require('bcrypt');
const logger = require('./logger');

class CryptoService {
    constructor() {
        // Chave de criptografia da variável de ambiente
        this.encryptionKey = process.env.ENCRYPTION_KEY;
        this.algorithm = process.env.CRYPTO_ALGORITHM || 'aes-256-gcm';
        this.saltRounds = parseInt(process.env.HASH_SALT_ROUNDS) || 12;
        
        if (!this.encryptionKey) {
            throw new Error('ENCRYPTION_KEY não configurada nas variáveis de ambiente');
        }
        
        // Deriva chave de 32 bytes para AES-256
        this.key = crypto.scryptSync(this.encryptionKey, 'salt', 32);
        
        console.log('🔒 CryptoService inicializado com AES-256-GCM');
    }

    /**
     * Criptografa dados sensíveis (dados médicos, CPF, etc.)
     */
    encrypt(plaintext) {
        try {
            if (!plaintext) {
                throw new Error('Texto para criptografia não pode ser vazio');
            }

            // Gera IV aleatório de 16 bytes
            const iv = crypto.randomBytes(16);
            
            // Cria cipher AES-256-CBC (compatível)
            const cipher = crypto.createCipher('aes-256-cbc', this.key);
            
            // Criptografa
            let encrypted = cipher.update(plaintext, 'utf8', 'hex');
            encrypted += cipher.final('hex');
            
            // Combina IV + Dados criptografados
            const result = {
                iv: iv.toString('hex'),
                encrypted: encrypted
            };
            
            // Retorna como base64 para armazenamento
            return Buffer.from(JSON.stringify(result)).toString('base64');
            
        } catch (error) {
            console.error('❌ Erro na criptografia:', error);
            throw new Error('Falha na criptografia de dados');
        }
    }

    /**
     * Descriptografa dados sensíveis
     */
    decrypt(encryptedData) {
        try {
            if (!encryptedData) {
                throw new Error('Dados criptografados não podem ser vazios');
            }

            // Decodifica de base64
            const data = JSON.parse(Buffer.from(encryptedData, 'base64').toString('utf8'));
            
            // Extrai componentes
            const iv = Buffer.from(data.iv, 'hex');
            const encrypted = data.encrypted;
            
            // Cria decipher AES-256-CBC (compatível)
            const decipher = crypto.createDecipher('aes-256-cbc', this.key);
            
            // Descriptografa
            let decrypted = decipher.update(encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            
            return decrypted;
            
        } catch (error) {
            console.error('❌ Erro na descriptografia:', error);
            throw new Error('Falha na descriptografia de dados');
        }
    }

    /**
     * Gera hash seguro para senhas
     */
    async hashPassword(password) {
        try {
            if (!password) {
                throw new Error('Senha não pode ser vazia');
            }

            const hash = await bcrypt.hash(password, this.saltRounds);
            console.log('🔐 Senha hasheada com sucesso');
            return hash;
            
        } catch (error) {
            console.error('❌ Erro no hash da senha:', error);
            throw new Error('Falha no hash da senha');
        }
    }

    /**
     * Verifica senha contra hash
     */
    async verifyPassword(password, hash) {
        try {
            if (!password || !hash) {
                return false;
            }

            const isValid = await bcrypt.compare(password, hash);
            console.log(`🔍 Verificação de senha: ${isValid ? 'SUCESSO' : 'FALHA'}`);
            return isValid;
            
        } catch (error) {
            console.error('❌ Erro na verificação da senha:', error);
            return false;
        }
    }

    /**
     * Criptografa dados médicos específicos
     */
    encryptMedicalData(medicalData) {
        try {
            const sensitiveFields = [
                'cpf', 'rg', 'telefone', 'endereco', 'email',
                'historico_medico', 'medicamentos', 'alergias',
                'observacoes_medicas', 'diagnostico'
            ];

            const encryptedData = { ...medicalData };

            for (const field of sensitiveFields) {
                if (encryptedData[field]) {
                    encryptedData[field] = this.encrypt(encryptedData[field].toString());
                }
            }

            console.log('🏥 Dados médicos criptografados com sucesso');
            return encryptedData;
            
        } catch (error) {
            console.error('❌ Erro na criptografia de dados médicos:', error);
            throw new Error('Falha na criptografia de dados médicos');
        }
    }

    /**
     * Descriptografa dados médicos específicos
     */
    decryptMedicalData(encryptedMedicalData) {
        try {
            const sensitiveFields = [
                'cpf', 'rg', 'telefone', 'endereco', 'email',
                'historico_medico', 'medicamentos', 'alergias',
                'observacoes_medicas', 'diagnostico'
            ];

            const decryptedData = { ...encryptedMedicalData };

            for (const field of sensitiveFields) {
                if (decryptedData[field]) {
                    decryptedData[field] = this.decrypt(decryptedData[field]);
                }
            }

            console.log('🏥 Dados médicos descriptografados com sucesso');
            return decryptedData;
            
        } catch (error) {
            console.error('❌ Erro na descriptografia de dados médicos:', error);
            throw new Error('Falha na descriptografia de dados médicos');
        }
    }
}

// Singleton
const cryptoService = new CryptoService();

module.exports = cryptoService;