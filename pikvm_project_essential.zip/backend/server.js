require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const RedisStore = require("connect-redis").default;
const redis = require("redis");
const { createServer } = require("http");
const { Server } = require("socket.io");
const winston = require("winston");
const path = require("path");

const authController = require("./authController");
const rateLimiter = require("./rateLimiter");
const logger = require("./logger");
const auditMiddleware = require("./auditMiddleware");
const cryptoService = require("./cryptoService");
const mfaService = require("./mfaService");
const captchaService = require("./captchaService");

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST"],
    credentials: true
  }
});

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";

const redisClient = redis.createClient({
  host: process.env.REDIS_HOST || "localhost",
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
  db: process.env.REDIS_DB || 0
});

redisClient.on("error", (err) => {
  logger.error("Redis connection error:", err);
});

redisClient.on("connect", () => {
  logger.info("Connected to Redis successfully");
});

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["\"self\""]
    }
  }
}));

app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"]
}));

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

app.use(session({
  store: new RedisStore({ 
    client: redisClient,
    prefix: "pikvm:sess:"
  }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  name: "pikvm.sid",
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 horas
    sameSite: "strict"
  }
}));

app.get("/health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || "1.0.0",
    environment: process.env.NODE_ENV || "development"
  });
});

server.listen(PORT, HOST, () => {
  logger.info(`🚀 PiKVM Medical Server started successfully!`, {
    port: PORT,
    host: HOST,
    environment: process.env.NODE_ENV || "development",
    timestamp: new Date().toISOString()
  });
});

module.exports = { app, server, io };


