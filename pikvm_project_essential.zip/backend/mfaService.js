/**
 * Serviço de Autenticação Multifator (MFA) - Sistema PiKVM Médico
 * 
 * Implementa TOTP (Time-based One-Time Password) compatível com Google Authenticator
 * Correção da falha crítica: Falta de autenticação multifator
 * 
 * ✅ TOTP com Google Authenticator
 * ✅ QR Code para configuração
 * ✅ Backup codes de emergência
 * ✅ Validação com janela de tempo
 */

const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const crypto = require('crypto');
const cryptoService = require('./cryptoService');

class MFAService {
    constructor() {
        this.issuer = process.env.MFA_ISSUER || 'PiKVM Medical System';
        this.window = parseInt(process.env.MFA_WINDOW) || 2;
        this.step = parseInt(process.env.MFA_STEP) || 30;
        
        console.log('🔐 MFAService inicializado com TOTP');
    }

    /**
     * Gera secret para novo usuário MFA
     * @param {string} userEmail - Email do usuário
     * @returns {Object} - Secret, QR code URL e backup codes
     */
    async generateMFASecret(userEmail) {
        try {
            // Gera secret único
            const secret = speakeasy.generateSecret({
                name: userEmail,
                issuer: this.issuer,
                length: 32
            });

            // Gera backup codes de emergência
            const backupCodes = this.generateBackupCodes();

            // Criptografa o secret antes de armazenar
            const encryptedSecret = cryptoService.encrypt(secret.base32);
            const encryptedBackupCodes = backupCodes.map(code => 
                cryptoService.encrypt(code)
            );

            // Gera QR Code
            const qrCodeUrl = await this.generateQRCode(secret.otpauth_url);

            console.log(`🔑 MFA secret gerado para: ${userEmail}`);

            return {
                secret: encryptedSecret,
                qrCode: qrCodeUrl,
                backupCodes: encryptedBackupCodes,
                manualEntryKey: secret.base32
            };

        } catch (error) {
            console.error('❌ Erro ao gerar MFA secret:', error);
            throw new Error('Falha na geração do MFA secret');
        }
    }

    /**
     * Verifica código TOTP
     * @param {string} token - Código de 6 dígitos
     * @param {string} encryptedSecret - Secret criptografado do usuário
     * @returns {boolean} - True se o código estiver válido
     */
    verifyTOTP(token, encryptedSecret) {
        try {
            if (!token || !encryptedSecret) {
                return false;
            }

            // Descriptografa o secret
            const secret = cryptoService.decrypt(encryptedSecret);

            // Verifica o token com janela de tempo
            const verified = speakeasy.totp.verify({
                secret: secret,
                encoding: 'base32',
                token: token,
                step: this.step,
                window: this.window
            });

            console.log(`🔍 Verificação TOTP: ${verified ? 'SUCESSO' : 'FALHA'} - Token: ${token}`);
            return verified;

        } catch (error) {
            console.error('❌ Erro na verificação TOTP:', error);
            return false;
        }
    }

    /**
     * Verifica backup code
     * @param {string} code - Código de backup
     * @param {Array} encryptedBackupCodes - Códigos de backup criptografados
     * @returns {Object} - {valid: boolean, remainingCodes: Array}
     */
    verifyBackupCode(code, encryptedBackupCodes) {
        try {
            if (!code || !encryptedBackupCodes || !Array.isArray(encryptedBackupCodes)) {
                return { valid: false, remainingCodes: encryptedBackupCodes };
            }

            // Descriptografa e verifica códigos
            for (let i = 0; i < encryptedBackupCodes.length; i++) {
                try {
                    const decryptedCode = cryptoService.decrypt(encryptedBackupCodes[i]);
                    
                    if (decryptedCode === code.toUpperCase()) {
                        // Remove o código usado
                        const remainingCodes = [...encryptedBackupCodes];
                        remainingCodes.splice(i, 1);
                        
                        console.log(`✅ Backup code válido usado. Restam: ${remainingCodes.length}`);
                        return { valid: true, remainingCodes };
                    }
                } catch (decryptError) {
                    // Código corrompido, pula para o próximo
                    continue;
                }
            }

            console.log('❌ Backup code inválido');
            return { valid: false, remainingCodes: encryptedBackupCodes };

        } catch (error) {
            console.error('❌ Erro na verificação de backup code:', error);
            return { valid: false, remainingCodes: encryptedBackupCodes };
        }
    }

    /**
     * Gera códigos de backup de emergência
     * @returns {Array} - Array com 10 códigos de backup
     */
    generateBackupCodes() {
        const codes = [];
        
        for (let i = 0; i < 10; i++) {
            // Gera código de 8 caracteres alfanuméricos
            const code = crypto.randomBytes(4).toString('hex').toUpperCase();
            codes.push(code);
        }

        console.log('🔑 10 códigos de backup gerados');
        return codes;
    }

    /**
     * Gera QR Code para configuração no app
     * @param {string} otpauthUrl - URL do TOTP
     * @returns {Promise<string>} - Data URL do QR Code
     */
    async generateQRCode(otpauthUrl) {
        try {
            const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl, {
                errorCorrectionLevel: 'M',
                type: 'image/png',
                quality: 0.92,
                margin: 1,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            });

            console.log('📱 QR Code gerado com sucesso');
            return qrCodeDataUrl;

        } catch (error) {
            console.error('❌ Erro ao gerar QR Code:', error);
            throw new Error('Falha na geração do QR Code');
        }
    }

    /**
     * Valida se MFA está configurado corretamente
     * @param {string} encryptedSecret - Secret criptografado
     * @returns {boolean} - True se MFA estiver configurado
     */
    isMFAConfigured(encryptedSecret) {
        try {
            if (!encryptedSecret) {
                return false;
            }

            // Tenta descriptografar para validar
            cryptoService.decrypt(encryptedSecret);
            return true;

        } catch (error) {
            return false;
        }
    }

    /**
     * Gera token TOTP atual (para testes)
     * @param {string} encryptedSecret - Secret criptografado
     * @returns {string} - Token atual de 6 dígitos
     */
    generateCurrentTOTP(encryptedSecret) {
        try {
            const secret = cryptoService.decrypt(encryptedSecret);
            
            const token = speakeasy.totp({
                secret: secret,
                encoding: 'base32',
                step: this.step
            });

            return token;

        } catch (error) {
            console.error('❌ Erro ao gerar TOTP atual:', error);
            throw new Error('Falha na geração do TOTP atual');
        }
    }

    /**
     * Desabilita MFA para um usuário
     * @param {string} userId - ID do usuário
     * @returns {boolean} - True se desabilitado com sucesso
     */
    async disableMFA(userId) {
        try {
            // Aqui você implementaria a lógica para remover MFA do banco
            // Por exemplo: UPDATE users SET mfa_secret = NULL WHERE id = userId
            
            console.log(`🔓 MFA desabilitado para usuário: ${userId}`);
            return true;

        } catch (error) {
            console.error('❌ Erro ao desabilitar MFA:', error);
            return false;
        }
    }

    /**
     * Valida configuração inicial do MFA
     * @param {string} token - Token fornecido pelo usuário
     * @param {string} secret - Secret em base32
     * @returns {boolean} - True se a configuração estiver correta
     */
    validateMFASetup(token, secret) {
        try {
            const verified = speakeasy.totp.verify({
                secret: secret,
                encoding: 'base32',
                token: token,
                step: this.step,
                window: this.window
            });

            console.log(`🔧 Validação de configuração MFA: ${verified ? 'SUCESSO' : 'FALHA'}`);
            return verified;

        } catch (error) {
            console.error('❌ Erro na validação de configuração MFA:', error);
            return false;
        }
    }
}

// Singleton
const mfaService = new MFAService();

module.exports = mfaService;

