// =================================
// SERVIDOR SIMPLIFICADO - PIKVM MÉDICO
// Versão básica para teste inicial
// =================================

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { createServer } = require('http');

const app = express();
const server = createServer(app);

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// =================================
// MIDDLEWARES BÁSICOS
// =================================

// Helmet para headers de segurança
app.use(helmet());

// CORS configurado
app.use(cors({
  origin: "*",
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Parsing de JSON
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging básico
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// =================================
// ROTAS BÁSICAS
// =================================

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    message: 'PiKVM Medical System is running!'
  });
});

app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    services: {
      backend: 'running',
      security: 'active',
      timestamp: new Date().toISOString()
    }
  });
});

// Rota de teste para autenticação
app.post('/api/auth/test', (req, res) => {
  res.json({
    message: 'Authentication endpoint is working!',
    timestamp: new Date().toISOString(),
    received: req.body
  });
});

// Rota de teste para PiKVM
app.get('/api/pikvm/status', (req, res) => {
  res.json({
    status: 'ready',
    message: 'PiKVM integration is ready',
    features: [
      'Remote KVM access',
      'Secure authentication',
      'Medical compliance',
      'Audit logging'
    ],
    timestamp: new Date().toISOString()
  });
});

// Rota para informações do sistema
app.get('/api/system/info', (req, res) => {
  res.json({
    system: 'PiKVM Medical System',
    version: '1.0.0',
    features: {
      security: {
        encryption: 'AES-256-GCM',
        authentication: 'JWT + MFA',
        audit: 'Complete logging',
        compliance: 'Medical standards'
      },
      pikvm: {
        remote_access: true,
        secure_connection: true,
        multi_user: true,
        session_recording: true
      }
    },
    status: 'operational',
    timestamp: new Date().toISOString()
  });
});

// =================================
// MIDDLEWARE DE ERRO
// =================================

app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
    timestamp: new Date().toISOString()
  });
});

// =================================
// ROTA 404
// =================================

app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Route not found',
    available_endpoints: [
      'GET /health',
      'GET /api/health',
      'POST /api/auth/test',
      'GET /api/pikvm/status',
      'GET /api/system/info'
    ],
    timestamp: new Date().toISOString()
  });
});

// =================================
// INICIALIZAÇÃO DO SERVIDOR
// =================================

server.listen(PORT, HOST, () => {
  console.log('🚀 PiKVM Medical Server (Simple) started successfully!');
  console.log(`📍 Server running at: http://${HOST}:${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`⏰ Started at: ${new Date().toISOString()}`);
  console.log('');
  console.log('📋 Available endpoints:');
  console.log('  GET  /health              - Health check');
  console.log('  GET  /api/health          - API health check');
  console.log('  POST /api/auth/test       - Authentication test');
  console.log('  GET  /api/pikvm/status    - PiKVM status');
  console.log('  GET  /api/system/info     - System information');
  console.log('');
  console.log('✅ Server is ready to receive requests!');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Process terminated');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Process terminated');
    process.exit(0);
  });
});

module.exports = { app, server };

