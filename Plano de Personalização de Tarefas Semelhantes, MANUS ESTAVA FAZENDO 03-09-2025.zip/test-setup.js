// =================================
// SCRIPT DE TESTE - PIKVM MÉDICO
// Verificar se todas as configurações estão corretas
// =================================

require('dotenv').config();
const fs = require('fs');
const path = require('path');

console.log('🔍 Verificando configuração do Sistema PiKVM Médico...\n');

// =================================
// VERIFICAR VARIÁVEIS DE AMBIENTE
// =================================

const requiredEnvVars = [
  'DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
  'REDIS_HOST', 'REDIS_PORT', 'REDIS_PASSWORD',
  'JWT_SECRET', 'ENCRYPTION_KEY', 'SESSION_SECRET'
];

console.log('📋 Verificando variáveis de ambiente:');
let envErrors = 0;

requiredEnvVars.forEach(varName => {
  const value = process.env[varName];
  if (!value) {
    console.log(`❌ ${varName}: AUSENTE`);
    envErrors++;
  } else {
    console.log(`✅ ${varName}: CONFIGURADA`);
  }
});

if (envErrors > 0) {
  console.log(`\n⚠️  ${envErrors} variáveis de ambiente estão ausentes!`);
} else {
  console.log('\n✅ Todas as variáveis de ambiente estão configuradas!');
}

// =================================
// VERIFICAR ARQUIVOS NECESSÁRIOS
// =================================

const requiredFiles = [
  'backend/server.js',
  'backend/package.json',
  'backend/Dockerfile',
  'backend/authController.js',
  'backend/rateLimiter.js',
  'backend/logger.js',
  'backend/cryptoService.js',
  'backend/mfaService.js',
  'nginx/nginx.conf',
  'nginx/ssl/pikvm-medical.crt',
  'nginx/ssl/pikvm-medical.key',
  'database/init.sql',
  'database/schema.sql',
  'database/seed.sql',
  'docker-compose.yml',
  '.env'
];

console.log('\n📁 Verificando arquivos necessários:');
let fileErrors = 0;

requiredFiles.forEach(filePath => {
  const fullPath = path.join(__dirname, filePath);
  if (fs.existsSync(fullPath)) {
    console.log(`✅ ${filePath}: EXISTE`);
  } else {
    console.log(`❌ ${filePath}: AUSENTE`);
    fileErrors++;
  }
});

if (fileErrors > 0) {
  console.log(`\n⚠️  ${fileErrors} arquivos necessários estão ausentes!`);
} else {
  console.log('\n✅ Todos os arquivos necessários estão presentes!');
}

// =================================
// VERIFICAR ESTRUTURA DE DIRETÓRIOS
// =================================

const requiredDirs = [
  'backend',
  'frontend',
  'nginx/conf.d',
  'nginx/ssl',
  'nginx/logs',
  'database',
  'redis',
  'coturn',
  'monitoring/prometheus',
  'monitoring/grafana',
  'backups',
  'uploads'
];

console.log('\n📂 Verificando estrutura de diretórios:');
let dirErrors = 0;

requiredDirs.forEach(dirPath => {
  const fullPath = path.join(__dirname, dirPath);
  if (fs.existsSync(fullPath)) {
    console.log(`✅ ${dirPath}/: EXISTE`);
  } else {
    console.log(`❌ ${dirPath}/: AUSENTE`);
    dirErrors++;
  }
});

if (dirErrors > 0) {
  console.log(`\n⚠️  ${dirErrors} diretórios necessários estão ausentes!`);
} else {
  console.log('\n✅ Toda a estrutura de diretórios está correta!');
}

// =================================
// VERIFICAR CERTIFICADOS SSL
// =================================

console.log('\n🔐 Verificando certificados SSL:');

const certPath = path.join(__dirname, 'nginx/ssl/pikvm-medical.crt');
const keyPath = path.join(__dirname, 'nginx/ssl/pikvm-medical.key');

if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
  console.log('✅ Certificados SSL estão presentes');
  
  // Verificar se os certificados não estão vazios
  const certSize = fs.statSync(certPath).size;
  const keySize = fs.statSync(keyPath).size;
  
  if (certSize > 0 && keySize > 0) {
    console.log('✅ Certificados SSL têm conteúdo válido');
  } else {
    console.log('❌ Certificados SSL estão vazios');
  }
} else {
  console.log('❌ Certificados SSL estão ausentes');
}

// =================================
// RESUMO FINAL
// =================================

console.log('\n' + '='.repeat(50));
console.log('📊 RESUMO DA VERIFICAÇÃO');
console.log('='.repeat(50));

const totalErrors = envErrors + fileErrors + dirErrors;

if (totalErrors === 0) {
  console.log('🎉 SUCESSO! Todas as configurações estão corretas!');
  console.log('✅ O sistema está pronto para ser iniciado com Docker Compose.');
  console.log('\n🚀 Para iniciar o sistema, execute:');
  console.log('   cd /home/ubuntu/pikvm_project');
  console.log('   docker-compose up -d');
} else {
  console.log(`❌ ERRO! ${totalErrors} problemas encontrados.`);
  console.log('⚠️  Corrija os problemas antes de iniciar o sistema.');
}

console.log('\n' + '='.repeat(50));

// =================================
// TESTE DE CONECTIVIDADE (OPCIONAL)
// =================================

console.log('\n🔌 Testando conectividade básica...');

// Teste de DNS
const dns = require('dns');
dns.lookup('google.com', (err) => {
  if (err) {
    console.log('❌ Conectividade de rede: FALHOU');
  } else {
    console.log('✅ Conectividade de rede: OK');
  }
});

// Verificar se as portas estão disponíveis
const net = require('net');

const portsToCheck = [80, 443, 3000, 5432, 6379];

portsToCheck.forEach(port => {
  const server = net.createServer();
  
  server.listen(port, (err) => {
    if (err) {
      console.log(`❌ Porta ${port}: EM USO`);
    } else {
      console.log(`✅ Porta ${port}: DISPONÍVEL`);
      server.close();
    }
  });
  
  server.on('error', (err) => {
    console.log(`❌ Porta ${port}: EM USO`);
  });
});

console.log('\n✨ Verificação concluída!');

