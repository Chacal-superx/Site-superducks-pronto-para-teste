-- =================================
-- SCRIPT DE INICIALIZAÇÃO - PIKVM MÉDICO
-- Configuração inicial do banco PostgreSQL
-- =================================

-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Configurar timezone
SET timezone = 'America/Sao_Paulo';

-- Criar usuário específico para a aplicação (se não existir)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'pikvm_app') THEN
        CREATE ROLE pikvm_app WITH LOGIN PASSWORD 'PiKVM_App_2024!@#$%';
    END IF;
END
$$;

-- Conceder permissões básicas
GRANT CONNECT ON DATABASE telemedicina TO pikvm_app;
GRANT USAGE ON SCHEMA public TO pikvm_app;
GRANT CREATE ON SCHEMA public TO pikvm_app;

-- Configurações de segurança do banco
ALTER DATABASE telemedicina SET log_statement = 'all';
ALTER DATABASE telemedicina SET log_min_duration_statement = 1000;
ALTER DATABASE telemedicina SET log_connections = on;
ALTER DATABASE telemedicina SET log_disconnections = on;

-- Função para auditoria automática
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (
            table_name, 
            operation, 
            old_values, 
            new_values, 
            user_id, 
            timestamp
        ) VALUES (
            TG_TABLE_NAME, 
            TG_OP, 
            NULL, 
            row_to_json(NEW), 
            current_setting('app.current_user_id', true), 
            NOW()
        );
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (
            table_name, 
            operation, 
            old_values, 
            new_values, 
            user_id, 
            timestamp
        ) VALUES (
            TG_TABLE_NAME, 
            TG_OP, 
            row_to_json(OLD), 
            row_to_json(NEW), 
            current_setting('app.current_user_id', true), 
            NOW()
        );
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (
            table_name, 
            operation, 
            old_values, 
            new_values, 
            user_id, 
            timestamp
        ) VALUES (
            TG_TABLE_NAME, 
            TG_OP, 
            row_to_json(OLD), 
            NULL, 
            current_setting('app.current_user_id', true), 
            NOW()
        );
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para criptografia de dados sensíveis
CREATE OR REPLACE FUNCTION encrypt_sensitive_data(data TEXT)
RETURNS TEXT AS $$
BEGIN
    RETURN encode(
        pgp_sym_encrypt(
            data, 
            current_setting('app.encryption_key', true),
            'compress-algo=1, cipher-algo=aes256'
        ), 
        'base64'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para descriptografia de dados sensíveis
CREATE OR REPLACE FUNCTION decrypt_sensitive_data(encrypted_data TEXT)
RETURNS TEXT AS $$
BEGIN
    RETURN pgp_sym_decrypt(
        decode(encrypted_data, 'base64'),
        current_setting('app.encryption_key', true)
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Configurar parâmetros de sessão para criptografia
ALTER DATABASE telemedicina SET app.encryption_key = 'AES_256_Encryption_Key_Medical_Data_2024!@#$%^&*()_+_SECURE';

COMMIT;

