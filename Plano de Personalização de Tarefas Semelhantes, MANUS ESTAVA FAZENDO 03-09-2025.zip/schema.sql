-- =================================
-- SCHEMA DO BANCO - PIKVM MÉDICO
-- Estrutura completa das tabelas
-- =================================

-- Tabela de auditoria (deve ser criada primeiro)
CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) NOT NULL,
    operation VARCHAR(10) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    user_id UUID,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT
);

-- Índices para performance da auditoria
CREATE INDEX IF NOT EXISTS idx_audit_log_table_name ON audit_log(table_name);
CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_log_user_id ON audit_log(user_id);

-- =================================
-- TABELAS DE USUÁRIOS E AUTENTICAÇÃO
-- =================================

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    salt VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user',
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    mfa_enabled BOOLEAN DEFAULT false,
    mfa_secret VARCHAR(255),
    backup_codes TEXT[], -- Códigos de backup para MFA
    last_login TIMESTAMP WITH TIME ZONE,
    login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- Tabela de sessões
CREATE TABLE IF NOT EXISTS user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    refresh_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address INET NOT NULL,
    user_agent TEXT,
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de tentativas de login
CREATE TABLE IF NOT EXISTS login_attempts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255),
    ip_address INET NOT NULL,
    user_agent TEXT,
    success BOOLEAN NOT NULL,
    failure_reason VARCHAR(100),
    attempted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =================================
-- TABELAS DE PERFIS MÉDICOS
-- =================================

-- Tabela de perfis médicos
CREATE TABLE IF NOT EXISTS medical_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    crm VARCHAR(20) UNIQUE NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    institution VARCHAR(200),
    phone VARCHAR(20),
    address TEXT,
    is_verified BOOLEAN DEFAULT false,
    verification_documents TEXT[], -- URLs dos documentos
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =================================
-- TABELAS DE PACIENTES
-- =================================

-- Tabela de pacientes
CREATE TABLE IF NOT EXISTS patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    -- Dados básicos (não criptografados para busca)
    patient_code VARCHAR(50) UNIQUE NOT NULL, -- Código interno
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10),
    
    -- Dados sensíveis (criptografados)
    encrypted_name TEXT NOT NULL, -- Nome criptografado
    encrypted_cpf TEXT, -- CPF criptografado
    encrypted_phone TEXT, -- Telefone criptografado
    encrypted_email TEXT, -- Email criptografado
    encrypted_address TEXT, -- Endereço criptografado
    
    -- Metadados
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- =================================
-- TABELAS DE CONSULTAS E SESSÕES PIKVM
-- =================================

-- Tabela de consultas
CREATE TABLE IF NOT EXISTS consultations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    doctor_id UUID NOT NULL REFERENCES users(id),
    consultation_type VARCHAR(50) NOT NULL, -- 'remote', 'pikvm', 'hybrid'
    status VARCHAR(20) NOT NULL DEFAULT 'scheduled', -- 'scheduled', 'in_progress', 'completed', 'cancelled'
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    
    -- Dados da consulta (criptografados)
    encrypted_notes TEXT,
    encrypted_diagnosis TEXT,
    encrypted_prescription TEXT,
    
    -- Metadados
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de sessões PiKVM
CREATE TABLE IF NOT EXISTS pikvm_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    consultation_id UUID NOT NULL REFERENCES consultations(id),
    pikvm_device_id VARCHAR(100) NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    vnc_password VARCHAR(100),
    webrtc_config JSONB,
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- 'pending', 'active', 'ended', 'error'
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    
    -- Logs de atividade
    activity_log JSONB DEFAULT '[]'::jsonb,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =================================
-- TABELAS DE ARQUIVOS E MÍDIA
-- =================================

-- Tabela de arquivos médicos
CREATE TABLE IF NOT EXISTS medical_files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    consultation_id UUID REFERENCES consultations(id),
    uploaded_by UUID NOT NULL REFERENCES users(id),
    
    -- Informações do arquivo
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(255) UNIQUE NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    
    -- Hash para integridade
    file_hash VARCHAR(64) NOT NULL,
    
    -- Criptografia
    is_encrypted BOOLEAN DEFAULT true,
    encryption_key_id VARCHAR(100),
    
    -- Metadados
    description TEXT,
    tags TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- =================================
-- TABELAS DE CONFIGURAÇÕES E LOGS
-- =================================

-- Tabela de configurações do sistema
CREATE TABLE IF NOT EXISTS system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    updated_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de logs de segurança
CREATE TABLE IF NOT EXISTS security_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL, -- 'low', 'medium', 'high', 'critical'
    user_id UUID REFERENCES users(id),
    ip_address INET,
    user_agent TEXT,
    event_data JSONB,
    message TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =================================
-- ÍNDICES PARA PERFORMANCE
-- =================================

-- Índices para usuários
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Índices para sessões
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions(expires_at);

-- Índices para tentativas de login
CREATE INDEX IF NOT EXISTS idx_login_attempts_ip ON login_attempts(ip_address);
CREATE INDEX IF NOT EXISTS idx_login_attempts_email ON login_attempts(email);
CREATE INDEX IF NOT EXISTS idx_login_attempts_attempted_at ON login_attempts(attempted_at);

-- Índices para pacientes
CREATE INDEX IF NOT EXISTS idx_patients_code ON patients(patient_code);
CREATE INDEX IF NOT EXISTS idx_patients_created_by ON patients(created_by);
CREATE INDEX IF NOT EXISTS idx_patients_created_at ON patients(created_at);

-- Índices para consultas
CREATE INDEX IF NOT EXISTS idx_consultations_patient_id ON consultations(patient_id);
CREATE INDEX IF NOT EXISTS idx_consultations_doctor_id ON consultations(doctor_id);
CREATE INDEX IF NOT EXISTS idx_consultations_scheduled_at ON consultations(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_consultations_status ON consultations(status);

-- Índices para sessões PiKVM
CREATE INDEX IF NOT EXISTS idx_pikvm_sessions_consultation_id ON pikvm_sessions(consultation_id);
CREATE INDEX IF NOT EXISTS idx_pikvm_sessions_device_id ON pikvm_sessions(pikvm_device_id);
CREATE INDEX IF NOT EXISTS idx_pikvm_sessions_status ON pikvm_sessions(status);

-- Índices para arquivos médicos
CREATE INDEX IF NOT EXISTS idx_medical_files_patient_id ON medical_files(patient_id);
CREATE INDEX IF NOT EXISTS idx_medical_files_consultation_id ON medical_files(consultation_id);
CREATE INDEX IF NOT EXISTS idx_medical_files_hash ON medical_files(file_hash);

-- Índices para logs de segurança
CREATE INDEX IF NOT EXISTS idx_security_logs_event_type ON security_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_security_logs_severity ON security_logs(severity);
CREATE INDEX IF NOT EXISTS idx_security_logs_user_id ON security_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_security_logs_created_at ON security_logs(created_at);

-- =================================
-- TRIGGERS DE AUDITORIA
-- =================================

-- Trigger para usuários
CREATE TRIGGER audit_users_trigger
    AFTER INSERT OR UPDATE OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Trigger para pacientes
CREATE TRIGGER audit_patients_trigger
    AFTER INSERT OR UPDATE OR DELETE ON patients
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Trigger para consultas
CREATE TRIGGER audit_consultations_trigger
    AFTER INSERT OR UPDATE OR DELETE ON consultations
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- Trigger para arquivos médicos
CREATE TRIGGER audit_medical_files_trigger
    AFTER INSERT OR UPDATE OR DELETE ON medical_files
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- =================================
-- POLÍTICAS DE SEGURANÇA RLS
-- =================================

-- Habilitar Row Level Security
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE consultations ENABLE ROW LEVEL SECURITY;
ALTER TABLE medical_files ENABLE ROW LEVEL SECURITY;

-- Política para pacientes (médicos só veem seus pacientes)
CREATE POLICY patients_access_policy ON patients
    FOR ALL TO pikvm_app
    USING (
        created_by = current_setting('app.current_user_id', true)::uuid
        OR 
        EXISTS (
            SELECT 1 FROM consultations c 
            WHERE c.patient_id = patients.id 
            AND c.doctor_id = current_setting('app.current_user_id', true)::uuid
        )
    );

-- Política para consultas
CREATE POLICY consultations_access_policy ON consultations
    FOR ALL TO pikvm_app
    USING (
        doctor_id = current_setting('app.current_user_id', true)::uuid
    );

-- Política para arquivos médicos
CREATE POLICY medical_files_access_policy ON medical_files
    FOR ALL TO pikvm_app
    USING (
        uploaded_by = current_setting('app.current_user_id', true)::uuid
        OR
        EXISTS (
            SELECT 1 FROM consultations c 
            WHERE c.id = medical_files.consultation_id 
            AND c.doctor_id = current_setting('app.current_user_id', true)::uuid
        )
    );

COMMIT;

