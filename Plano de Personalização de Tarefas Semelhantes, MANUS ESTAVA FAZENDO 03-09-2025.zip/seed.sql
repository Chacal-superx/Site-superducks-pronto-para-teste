-- =================================
-- DADOS INICIAIS - PIKVM MÉDICO
-- Seed data para desenvolvimento e testes
-- =================================

-- Inserir configurações iniciais do sistema
INSERT INTO system_settings (key, value, description, is_encrypted) VALUES
('system_name', 'PiKVM Médico', 'Nome do sistema', false),
('system_version', '1.0.0', 'Versão atual do sistema', false),
('max_login_attempts', '5', 'Máximo de tentativas de login', false),
('session_timeout', '24', 'Timeout da sessão em horas', false),
('mfa_required', 'true', 'MFA obrigatório para todos os usuários', false),
('backup_retention_days', '30', 'Dias de retenção de backup', false),
('log_retention_days', '365', 'Dias de retenção de logs', false),
('max_file_size_mb', '50', 'Tamanho máximo de arquivo em MB', false),
('allowed_file_types', 'pdf,jpg,jpeg,png,doc,docx,txt', 'Tipos de arquivo permitidos', false),
('encryption_enabled', 'true', 'Criptografia habilitada', false)
ON CONFLICT (key) DO NOTHING;

-- Criar usuário administrador padrão
-- Senha: Admin@2024! (deve ser alterada no primeiro login)
INSERT INTO users (
    id,
    email, 
    password_hash, 
    salt,
    first_name, 
    last_name, 
    role, 
    is_active, 
    is_verified,
    mfa_enabled
) VALUES (
    uuid_generate_v4(),
    'admin@pikvm-medico.local',
    '$2b$12$LQv3c1yqBwEHxv5hSRgUeOH9HvJ8H8H8H8H8H8H8H8H8H8H8H8H8H8', -- Hash da senha Admin@2024!
    'salt_admin_2024',
    'Administrador',
    'Sistema',
    'admin',
    true,
    true,
    false
) ON CONFLICT (email) DO NOTHING;

-- Criar usuário médico de exemplo
-- Senha: Medico@2024!
INSERT INTO users (
    id,
    email, 
    password_hash, 
    salt,
    first_name, 
    last_name, 
    role, 
    is_active, 
    is_verified,
    mfa_enabled
) VALUES (
    uuid_generate_v4(),
    'dr.exemplo@pikvm-medico.local',
    '$2b$12$LQv3c1yqBwEHxv5hSRgUeOH9HvJ8H8H8H8H8H8H8H8H8H8H8H8H8H9', -- Hash da senha Medico@2024!
    'salt_medico_2024',
    'Dr. João',
    'Silva',
    'doctor',
    true,
    true,
    true
) ON CONFLICT (email) DO NOTHING;

-- Criar perfil médico para o usuário de exemplo
INSERT INTO medical_profiles (
    user_id,
    crm,
    specialty,
    institution,
    phone,
    is_verified
) VALUES (
    (SELECT id FROM users WHERE email = 'dr.exemplo@pikvm-medico.local'),
    'CRM/SP 123456',
    'Cardiologia',
    'Hospital Exemplo',
    '+55 11 99999-9999',
    true
) ON CONFLICT (crm) DO NOTHING;

-- Inserir logs de segurança iniciais
INSERT INTO security_logs (event_type, severity, message, event_data) VALUES
('system_startup', 'medium', 'Sistema iniciado com sucesso', '{"version": "1.0.0", "environment": "production"}'),
('database_initialized', 'medium', 'Banco de dados inicializado', '{"tables_created": 15, "indexes_created": 25}'),
('security_policies_applied', 'high', 'Políticas de segurança aplicadas', '{"rls_enabled": true, "audit_triggers": true}');

-- Inserir dados de auditoria inicial
INSERT INTO audit_log (table_name, operation, new_values, user_id, timestamp) VALUES
('system_settings', 'INSERT', '{"action": "initial_setup"}', NULL, NOW()),
('users', 'INSERT', '{"action": "admin_user_created"}', NULL, NOW()),
('medical_profiles', 'INSERT', '{"action": "example_doctor_profile_created"}', NULL, NOW());

COMMIT;

